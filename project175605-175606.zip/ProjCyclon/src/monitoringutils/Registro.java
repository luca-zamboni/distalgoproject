/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package monitoringutils;

import java.util.ArrayList;
import projcyclon.Peer;

/**
 *
 * @author luca
 */
public class Registro {
    
    public static ArrayList<Peer> reg = new ArrayList<>();
    
    public static ArrayList<Peer> mal = new ArrayList<>();
    
}
