The report is in the folder ./report/

The data used to build graphs of the paper are in the folder ./ProjCyclon/data

The executable .jar file is in the folder  ./ProjCyclon/Jar/
you can execute it moving in that folder and typing in the terminal:
java -jar ProjCyclon.jar 


